// Perguntas
const perguntas = [
  {
    pergunta: "Pitágoras não gostava da Matemática, por isso criou a Filosofia",
    correta: 1 // 1 = Falso
  },
  {
    pergunta: "Pitágoras foi o primeiro filósofo grego conhecido",
    correta: 1 
  },
  {
    pergunta: "A palavra \"filosofia\" foi criada por Pitágoras no séc. VI a.C.",
    correta: 0 // 0 = Verdadeiro  
  },
  {
    pergunta: "Os primeiros filósofos eram conhecidos como Filósofos Físicos",
    correta: 0 
  },
  {
    pergunta: "Temas como os problemas da vida humana, possibilidade do conhecer, era o objetivo dos filósofos Físicos",
    correta: 1 
  },
  {
    pergunta: "Platão era um filósofo \"físico\"",
    correta: 1 
  },
  {
    pergunta: "A capacidade de admirar fez surgir a filosofia, diz Platão",
    correta: 0 
  },
  {
    pergunta: "Uma reflexão filosófica não pode ser vista como uma reflexão qualquer",
    correta: 0 
  },
  {
    pergunta: "Ser radical significa ir até as raízes da questão, o mais profundo",
    correta: 0 
  },
  {
    pergunta: "O filósofo ignora uma sequência lógica em sua análise por agir livremente",
    correta: 1 
  }
];