// Perguntas
const perguntas = [
  {
    pergunta: "A filosofia e o mito são sinônimos porque tratam das mesmas coisas",
    correta: 1 // 1 = Falso
  },
  {
    pergunta: "Mitos existem como uma forma importante para se transmitir uma informação",
    correta: 0 // 0 = Verdadeiro
  },
  {
    pergunta: "Mitos são histórias fantasiosas e inventadas, igual um desenho animado",
    correta: 1  
  },
  {
    pergunta: "Os mitos foram as primeiras formas dos homens transmitirem suas ideias",
    correta: 0 
  },
  {
    pergunta: "As pessoas morrem, nascem, todos os dias. Por isso o mito aparece, para explicar esses fenômenos",
    correta: 0 
  },
  {
    pergunta: "Mito é um sistema incoerente, desordenado de dizer a realidade",
    correta: 1 
  },
  {
    pergunta: "Mito é um discurso direto, racional, papo reto",
    correta: 1 
  },
  {
    pergunta: "Parte do mito fica no mito pois é indizível à razão, simbólico",
    correta: 0 
  },
  {
    pergunta: "Os mitos foram as primeiras formas dos homens transmitirem suas ideias",
    correta: 0 
  },
  {
    pergunta: "Quando o mito vai para o cinema, deixa de ser mito e vira fantasia",
    correta: 1 
  }
];
